package com.sam.notification.dto;

public class NotificationDTO {

    private Long id;
    private String message;
    private String recipient;

    // Default constructor
    public NotificationDTO() {
    }

    // Parameterized constructor
    public NotificationDTO(Long id, String message, String recipient) {
        this.id = id;
        this.message = message;
        this.recipient = recipient;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getRecipient() {
        return recipient;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    @Override
    public String toString() {
        return "NotificationDTO{" +
                "id=" + id +
                ", message='" + message + '\'' +
                ", recipient='" + recipient + '\'' +
                '}';
    }
}
