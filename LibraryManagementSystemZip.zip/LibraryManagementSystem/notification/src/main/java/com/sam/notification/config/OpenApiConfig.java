package com.sam.notification.config;

import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public GroupedOpenApi notificationApi() {
        return GroupedOpenApi.builder()
            .group("notification") // Name of the group in the Swagger UI
            .pathsToMatch("/api/notifications/**") // URL pattern for this group
            .build();
    }
    @Bean
    public GroupedOpenApi adminApi() {
        return GroupedOpenApi.builder()
            .group("admin-service")
            .pathsToMatch("/api/admin/**")
            .build();
    }
}
