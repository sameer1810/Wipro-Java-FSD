package com.sam.notification.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sam.notification.model.Notification;

public interface NotificationRepository extends JpaRepository<Notification, Long> {
}

