package com.sam.notification.service;

import com.sam.notification.config.NotificationWebSocketHandler;
import com.sam.notification.dto.NotificationDTO;
import com.sam.notification.model.Notification;
import com.sam.notification.repository.NotificationRepository;
import com.sam.notification.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class NotificationService {

    private static final Logger logger = LoggerFactory.getLogger(NotificationService.class);

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private NotificationWebSocketHandler notificationWebSocketHandler; // Inject WebSocket handler

    // Get all notifications
    public List<NotificationDTO> getAllNotifications() {
        logger.info("Fetching all notifications");
        return notificationRepository.findAll().stream()
            .map(this::convertToDTO)
            .collect(Collectors.toList());
    }

    // Get notification by ID
    public NotificationDTO getNotificationById(Long id) {
        logger.info("Fetching notification with id: {}", id);
        Notification notification = notificationRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Notification not found with id " + id));
        return convertToDTO(notification);
    }

    // Save or update notification
    @Transactional
    public NotificationDTO saveNotification(NotificationDTO notificationDTO) {
        logger.info("Saving notification: {}", notificationDTO);
        Notification notification = convertToEntity(notificationDTO);
        Notification savedNotification = notificationRepository.save(notification);

        // Notify via WebSocket
        String message = "Notification updated: " + savedNotification;
        notificationWebSocketHandler.sendMessageToAllSessions(message);

        return convertToDTO(savedNotification);
    }

    // Delete notification by ID
    @Transactional
    public void deleteNotification(Long id) {
        logger.info("Deleting notification with id: {}", id);
        if (!notificationRepository.existsById(id)) {
            throw new ResourceNotFoundException("Notification not found with id " + id);
        }
        notificationRepository.deleteById(id);

        // Notify via WebSocket
        String message = "Notification deleted with id: " + id;
        notificationWebSocketHandler.sendMessageToAllSessions(message);
    }

    // Convert entity to DTO
    private NotificationDTO convertToDTO(Notification notification) {
        return new NotificationDTO(
            notification.getId(),
            notification.getMessage(),
            notification.getRecipient()
        );
    }

    // Convert DTO to entity
    private Notification convertToEntity(NotificationDTO notificationDTO) {
        return new Notification(
            notificationDTO.getId(),
            notificationDTO.getMessage(),
            notificationDTO.getRecipient()
        );
    }
}
