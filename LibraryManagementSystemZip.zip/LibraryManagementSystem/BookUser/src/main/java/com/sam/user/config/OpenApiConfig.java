package com.sam.user.config;

import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public GroupedOpenApi userApi() {
        return GroupedOpenApi.builder()
            .group("BookUser") // Name of the group in the Swagger UI
            .pathsToMatch("/api/users/**") // URL pattern for this group
            .build();
    }

    @Bean
    public GroupedOpenApi adminApi() {
        return GroupedOpenApi.builder()
            .group("admin-service")
            .pathsToMatch("/api/admin/**")
            .build();
    }
}
