package com.sam.book.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sam.book.dto.BookDTO;
import com.sam.book.exception.ResourceNotFoundException;
import com.sam.book.model.Book;
import com.sam.book.repository.BookRepository;

@Service
public class BookService {

	@Autowired
    private BookRepository BookRepository;

    public List<BookDTO> getAllBooks() {
        return BookRepository.findAll().stream()
            .map(this::convertToDTO)
            .collect(Collectors.toList());
    }

    public BookDTO getBookById(Long id) {
        return convertToDTO(BookRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Book not found with id " + id)));
    }

    public BookDTO saveBook(BookDTO BookDTO) {
        Book Book = convertToEntity(BookDTO);
        return convertToDTO(BookRepository.save(Book));
    }

    public void deleteBook(Long id) {
        BookRepository.deleteById(id);
    }

    private BookDTO convertToDTO(Book Book) {
        return new BookDTO(Book.getId(), Book.getName(), Book.getAuthor(), Book.getQuantity());
    }

    private Book convertToEntity(BookDTO BookDTO) {
        return new Book(BookDTO.getId(), BookDTO.getName(), BookDTO.getAuthor(), BookDTO.getQuantity());
    }
}
