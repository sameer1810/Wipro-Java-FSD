package com.sam.borrow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BorrowingApplicationTests {

	@Test
	void contextLoads() {
	}

}
