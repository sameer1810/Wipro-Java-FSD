package com.sam.borrow.service;

import com.sam.borrow.dto.BorrowDTO;
import com.sam.borrow.model.Borrow;
import com.sam.borrow.repository.BorrowRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class BorrowService {

    private final BorrowRepository borrowRepository;

    public BorrowService(BorrowRepository borrowRepository) {
        this.borrowRepository = borrowRepository;
    }

    public BorrowDTO createBorrow(BorrowDTO borrowDTO) {
        Borrow borrow = mapToEntity(borrowDTO);
        // Set the initial returned status to false when creating a new borrow
        borrow.setReturned(false);
        borrow = borrowRepository.save(borrow);
        return mapToDTO(borrow);
    }

    public BorrowDTO getBorrowById(Long id) {
        Borrow borrow = borrowRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Borrow not found"));
        return mapToDTO(borrow);
    }

    public List<BorrowDTO> getAllBorrows() {
        return borrowRepository.findAll().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    public BorrowDTO updateBorrow(Long id, BorrowDTO borrowDTO) {
        Borrow existingBorrow = borrowRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Borrow not found"));

        // Update existing borrow entity fields from borrowDTO
        existingBorrow.setUserId(borrowDTO.getUserId());
        existingBorrow.setBookId(borrowDTO.getBookId());
        existingBorrow.setBorrowDate(borrowDTO.getBorrowDate());
        existingBorrow.setReturnDate(borrowDTO.getReturnDate());
        existingBorrow.setReturned(borrowDTO.getReturned());

        existingBorrow = borrowRepository.save(existingBorrow);
        return mapToDTO(existingBorrow);
    }

    public void deleteBorrow(Long id) {
        if (!borrowRepository.existsById(id)) {
            throw new RuntimeException("Borrow not found");
        }
        borrowRepository.deleteById(id);
    }

    public BorrowDTO markAsReturned(Long id) {
        Borrow borrow = borrowRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Borrow not found"));

        // Set returned status to true
        borrow.setReturned(true);
        borrow = borrowRepository.save(borrow);
        return mapToDTO(borrow);
    }

    private BorrowDTO mapToDTO(Borrow borrow) {
        BorrowDTO borrowDTO = new BorrowDTO();
        borrowDTO.setId(borrow.getId());
        borrowDTO.setUserId(borrow.getUserId());
        borrowDTO.setBookId(borrow.getBookId());
        borrowDTO.setBorrowDate(borrow.getBorrowDate());
        borrowDTO.setReturnDate(borrow.getReturnDate());
        borrowDTO.setReturned(borrow.isReturned());
        return borrowDTO;
    }

    private Borrow mapToEntity(BorrowDTO borrowDTO) {
        Borrow borrow = new Borrow();
        borrow.setUserId(borrowDTO.getUserId());
        borrow.setBookId(borrowDTO.getBookId());
        borrow.setBorrowDate(borrowDTO.getBorrowDate());
        borrow.setReturnDate(borrowDTO.getReturnDate());
        borrow.setReturned(borrowDTO.getReturned());
        return borrow;
    }
}
