package com.sam.borrow.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Positive;

public class BookDTO {
	private Long id;

    @NotBlank(message = "Name cannot be blank")
    private String name;

    @NotBlank(message = "author cannot be blank")
    private String author;

    @Positive(message = "quantity must be greater than 0")
    private int quantity;

    // Default constructor
    public BookDTO() {
    }

    // Parameterized constructor
    public BookDTO(Long id, String name, String author, int quantity) {
        this.id = id;
        this.name = name;
        this.author = author;
        this.quantity = quantity;
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
