package com.sam.borrow.controller;

import com.sam.borrow.dto.BorrowDTO;
import com.sam.borrow.service.BorrowService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/borrows")
@Tag(name = "Borrow Controller", description = "Controller for managing borrow entries")
public class BorrowController {

    private final BorrowService borrowService;

    // Constructor injection for BorrowService
    public BorrowController(BorrowService borrowService) {
        this.borrowService = borrowService;
    }

    @Operation(summary = "Create a new borrow entry")
    @PostMapping
    public ResponseEntity<BorrowDTO> createBorrow(@Valid @RequestBody BorrowDTO borrowDTO) {
        // Ensure borrow date and returned status are managed
        BorrowDTO createdBorrow = borrowService.createBorrow(borrowDTO);
        return ResponseEntity.ok(createdBorrow);
    }

    @Operation(summary = "Get a borrow entry by ID")
    @GetMapping("/{id}")
    public ResponseEntity<BorrowDTO> getBorrowById(@PathVariable Long id) {
        BorrowDTO borrow = borrowService.getBorrowById(id);
        return ResponseEntity.ok(borrow);
    }

    @Operation(summary = "Get all borrow entries")
    @GetMapping
    public ResponseEntity<List<BorrowDTO>> getAllBorrows() {
        List<BorrowDTO> borrows = borrowService.getAllBorrows();
        return ResponseEntity.ok(borrows);
    }

    @Operation(summary = "Update a borrow entry by ID")
    @PutMapping("/{id}")
    public ResponseEntity<BorrowDTO> updateBorrow(@PathVariable Long id, @Valid @RequestBody BorrowDTO borrowDTO) {
        BorrowDTO updatedBorrow = borrowService.updateBorrow(id, borrowDTO);
        return ResponseEntity.ok(updatedBorrow);
    }

    @Operation(summary = "Delete a borrow entry by ID")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBorrow(@PathVariable Long id) {
        borrowService.deleteBorrow(id);
        return ResponseEntity.noContent().build();
    }

    @Operation(summary = "Mark a borrow entry as returned")
    @PutMapping("/{id}/return")
    public ResponseEntity<BorrowDTO> markAsReturned(@PathVariable Long id) {
        BorrowDTO returnedBorrow = borrowService.markAsReturned(id);
        return ResponseEntity.ok(returnedBorrow);
    }
}
