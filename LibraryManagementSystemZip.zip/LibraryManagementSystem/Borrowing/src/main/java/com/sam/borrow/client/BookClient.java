package com.sam.borrow.client;

import com.sam.borrow.dto.BookDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "Book")
public interface BookClient {
    @GetMapping("/books/{id}")
    BookDTO getBookById(@PathVariable("id") Long id);
}

