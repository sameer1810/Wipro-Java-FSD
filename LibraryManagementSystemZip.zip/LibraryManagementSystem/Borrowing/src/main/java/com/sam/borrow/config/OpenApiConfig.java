package com.sam.borrow.config;

import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public GroupedOpenApi borrowingApi() {
        return GroupedOpenApi.builder()
                .group("borrowing-api")
                .pathsToMatch("/borrows/**") // Adjusted to match your controller's path
                .build();
    }

    @Bean
    public GroupedOpenApi adminApi() {
        return GroupedOpenApi.builder()
                .group("admin-service")
                .pathsToMatch("/api/admin/**")
                .build();
    }
}
